请使用 python 3.9，使用前需要安装依赖: pip3 install -r requirements.txt<br>
使用websockt时，需要修改这四个参数的值：bot_app_key, secret_id, secret_key, visitor_biz_id<br>
使用sse时，需要修改这二个参数的值：bot_app_key, visitor_biz_id<br>
